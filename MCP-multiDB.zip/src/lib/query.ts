import { eq, desc } from 'drizzle-orm';
import { masterDb } from './master-db';
import { 
  getTenantDb, 
  createNoteInTenant, 
  getNotesFromTenant, 
  deleteNoteFromTenant,
  markProjectAsRead 
} from './tenant-db';
import { users, projects, type NewUser, type NewProject } from '../db/schema';

// User queries
export async function getUserByEmail(email: string) {
  return masterDb.query.users.findFirst({
    where: eq(users.email, email),
  });
}

export async function getUserById(id: number) {
  return masterDb.query.users.findFirst({
    where: eq(users.id, id),
  });
}

export async function createUser(data: NewUser) {
  const result = await masterDb.insert(users).values(data).returning();
  return result[0];
}

export async function getAllProjects() {
  return masterDb.query.projects.findMany({
    orderBy: desc(projects.createdAt),
  });
}

export async function getProjectById(id: number) {
  return masterDb.query.projects.findFirst({
    where: eq(projects.id, id),
  });
}

export async function getProjectBySlug(slug: string) {
  return masterDb.query.projects.findFirst({
    where: eq(projects.slug, slug),
  });
}

export async function createProject(data: NewProject) {
  const result = await masterDb.insert(projects).values(data).returning();
  return result[0];
}

export async function updateProjectStatus(id: number, status: 'draft' | 'review' | 'done') {
  const result = await masterDb
    .update(projects)
    .set({ status })
    .where(eq(projects.id, id))
    .returning();
  return result[0];
}

export async function deleteProject(id: number) {
  return masterDb.delete(projects).where(eq(projects.id, id));
}

// Multi-Tenant Notes Operations
// Notes are now stored in individual tenant DBs based on project slug

export async function getNotesByProjectSlug(slug: string) {
  return getNotesFromTenant(slug);
}

// For backward compatibility - get project first then fetch notes
export async function getNotesByProjectId(projectId: number) {
  const project = await getProjectById(projectId);
  if (!project) return [];
  return getNotesFromTenant(project.slug);
}

export async function createNote(data: {
  slug: string;
  content: string;
  authorRole: 'admin' | 'client';
  authorName: string;
  attachmentUrl?: string;
  attachmentType?: string;
  attachmentName?: string;
}) {
  return createNoteInTenant(data.slug, {
    content: data.content,
    authorRole: data.authorRole,
    authorName: data.authorName,
    attachmentUrl: data.attachmentUrl,
    attachmentType: data.attachmentType,
    attachmentName: data.attachmentName,
  });
}

export async function deleteNote(slug: string, noteId: number) {
  return deleteNoteFromTenant(slug, noteId);
}

export async function markAsRead(slug: string) {
  return markProjectAsRead(slug);
}

export async function getProjectByShareToken(token: string) {
  return masterDb.query.projects.findFirst({
    where: eq(projects.shareToken, token),
  });
}

export async function updateProjectStatusByShareToken(token: string, status: 'draft' | 'review' | 'done') {
  const result = await masterDb
    .update(projects)
    .set({ status })
    .where(eq(projects.shareToken, token))
    .returning();
  return result[0];
}
