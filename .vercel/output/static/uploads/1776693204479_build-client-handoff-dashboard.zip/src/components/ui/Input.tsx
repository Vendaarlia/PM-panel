import { cn } from "@/utils/cn";
import type { InputHTMLAttributes } from "react";

interface Props extends InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
}

export function Input({ label, error, className, id, ...rest }: Props) {
  return (
    <div className="flex flex-col gap-1">
      {label && (
        <label
          htmlFor={id}
          className="text-xs font-medium text-zinc-500 uppercase tracking-wider"
        >
          {label}
        </label>
      )}
      <input
        id={id}
        {...rest}
        className={cn(
          "w-full rounded-lg border border-zinc-200 bg-white px-3 py-2 text-sm text-zinc-900 placeholder-zinc-400",
          "focus:outline-none focus:ring-2 focus:ring-zinc-900/10 focus:border-zinc-400",
          "transition-colors duration-150",
          error && "border-red-300 focus:ring-red-200",
          className
        )}
      />
      {error && <p className="text-xs text-red-500">{error}</p>}
    </div>
  );
}
