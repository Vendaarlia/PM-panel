import type { ProjectStatus } from "@/db/schema";

const config: Record<ProjectStatus, { label: string; classes: string }> = {
  draft: {
    label: "Draft",
    classes: "bg-zinc-100 text-zinc-500 border-zinc-200",
  },
  review: {
    label: "In Review",
    classes: "bg-amber-50 text-amber-600 border-amber-200",
  },
  done: {
    label: "Done",
    classes: "bg-emerald-50 text-emerald-600 border-emerald-200",
  },
};

interface Props {
  status: ProjectStatus;
  size?: "sm" | "md";
}

export function StatusBadge({ status, size = "md" }: Props) {
  const { label, classes } = config[status];
  const sizeClasses = size === "sm" ? "text-[10px] px-1.5 py-0.5" : "text-xs px-2 py-1";
  return (
    <span
      className={`inline-flex items-center rounded-full border font-medium tracking-wide ${sizeClasses} ${classes}`}
    >
      {label}
    </span>
  );
}
