// components/vue/ProjectList.tsx
// Equivalent to ProjectList.vue — handles state and navigation.

import { StatusBadge } from "@/components/ui/StatusBadge";
import { Button } from "@/components/ui/Button";
import { apiDeleteProject } from "@/lib/query";
import type { Project } from "@/db/schema";

interface Props {
  projects: Project[];
  onSelect: (id: string) => void;
  onDelete: (id: string) => void;
}

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString("en-GB", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

export function ProjectList({ projects, onSelect, onDelete }: Props) {
  function handleDelete(e: React.MouseEvent, id: string) {
    e.stopPropagation();
    if (!confirm("Delete this project and all its notes?")) return;
    apiDeleteProject(id);
    onDelete(id);
  }

  if (projects.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center gap-3">
        <div className="w-10 h-10 rounded-full bg-zinc-100 flex items-center justify-center text-zinc-400">
          <svg width="18" height="18" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 12.75V12A2.25 2.25 0 014.5 9.75h15A2.25 2.25 0 0121.75 12v.75m-8.69-6.44l-2.12-2.12a1.5 1.5 0 00-1.061-.44H4.5A2.25 2.25 0 002.25 6v12a2.25 2.25 0 002.25 2.25h15A2.25 2.25 0 0021.75 18V9a2.25 2.25 0 00-2.25-2.25h-5.379a1.5 1.5 0 01-1.06-.44z" />
          </svg>
        </div>
        <p className="text-sm text-zinc-400">No projects yet. Create your first one.</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col divide-y divide-zinc-100 border border-zinc-200 rounded-xl bg-white overflow-hidden">
      {projects.map((project) => (
        <div
          key={project.id}
          onClick={() => onSelect(project.id)}
          className="group flex items-center gap-4 px-5 py-4 cursor-pointer hover:bg-zinc-50 transition-colors duration-100"
        >
          {/* Status dot */}
          <span
            className={`flex-shrink-0 w-2 h-2 rounded-full mt-0.5 ${
              project.status === "draft"
                ? "bg-zinc-300"
                : project.status === "review"
                ? "bg-amber-400"
                : "bg-emerald-400"
            }`}
          />

          {/* Main info */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium text-zinc-900 truncate">
                {project.name}
              </span>
              <StatusBadge status={project.status} size="sm" />
            </div>
            <p className="text-xs text-zinc-400 mt-0.5 truncate">
              {project.client} · {formatDate(project.created_at)}
            </p>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity duration-100">
            <Button
              variant="danger"
              size="sm"
              onClick={(e) => handleDelete(e, project.id)}
            >
              Delete
            </Button>
            <Button variant="outline" size="sm" onClick={(e) => { e.stopPropagation(); onSelect(project.id); }}>
              Open →
            </Button>
          </div>
        </div>
      ))}
    </div>
  );
}
