// components/vue/Notes.tsx
// Equivalent to Notes.vue — handles note creation, listing, and deletion.

import { useState } from "react";
import { Textarea } from "@/components/ui/Textarea";
import { Button } from "@/components/ui/Button";
import { apiCreateNote, apiDeleteNote } from "@/lib/query";
import type { Note } from "@/db/schema";

interface Props {
  projectId: string;
  initialNotes: Note[];
}

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString("en-GB", {
    day: "numeric",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function Notes({ projectId, initialNotes }: Props) {
  const [notes, setNotes] = useState<Note[]>(initialNotes);
  const [content, setContent] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleAdd(e: React.FormEvent) {
    e.preventDefault();
    if (!content.trim()) {
      setError("Note cannot be empty.");
      return;
    }
    setError("");
    setLoading(true);
    try {
      const note = apiCreateNote(projectId, content);
      setNotes([note, ...notes]);
      setContent("");
    } finally {
      setLoading(false);
    }
  }

  function handleDelete(id: string) {
    if (!confirm("Delete this note?")) return;
    apiDeleteNote(id);
    setNotes(notes.filter((n) => n.id !== id));
  }

  return (
    <div className="flex flex-col gap-5">
      {/* Add note form */}
      <form onSubmit={handleAdd} className="flex flex-col gap-2">
        <Textarea
          id="note-content"
          label="Add a note"
          placeholder="Summarise feedback, decisions, next steps…"
          rows={3}
          value={content}
          onChange={(e) => setContent(e.target.value)}
          error={error}
        />
        <div>
          <Button type="submit" size="sm" loading={loading}>
            Add note
          </Button>
        </div>
      </form>

      {/* Notes list */}
      {notes.length === 0 ? (
        <p className="text-xs text-zinc-400 text-center py-6">
          No notes yet. Add context, feedback, or decisions above.
        </p>
      ) : (
        <div className="flex flex-col gap-3">
          {notes.map((note) => (
            <div
              key={note.id}
              className="group relative bg-white border border-zinc-200 rounded-xl px-4 py-3"
            >
              <p className="text-sm text-zinc-700 whitespace-pre-wrap leading-relaxed">
                {note.content}
              </p>
              <div className="flex items-center justify-between mt-2.5">
                <span className="text-[10px] text-zinc-400">
                  {formatDate(note.created_at)}
                </span>
                <button
                  onClick={() => handleDelete(note.id)}
                  className="text-[10px] text-zinc-300 hover:text-red-400 transition-colors duration-100 opacity-0 group-hover:opacity-100"
                >
                  Delete
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
