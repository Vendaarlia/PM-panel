// components/vue/ProjectForm.tsx
// Equivalent to ProjectForm.vue — handles form input, state, and API calls.

import { useState } from "react";
import { Input } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";
import { apiCreateProject } from "@/lib/query";
import type { Project } from "@/db/schema";

interface Props {
  onCreated: (project: Project) => void;
  onCancel: () => void;
}

export function ProjectForm({ onCreated, onCancel }: Props) {
  const [name, setName] = useState("");
  const [client, setClient] = useState("");
  const [errors, setErrors] = useState<{ name?: string; client?: string }>({});
  const [loading, setLoading] = useState(false);

  function validate(): boolean {
    const e: typeof errors = {};
    if (!name.trim()) e.name = "Project name is required.";
    if (!client.trim()) e.client = "Client name is required.";
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!validate()) return;
    setLoading(true);
    try {
      const project = apiCreateProject(name, client);
      onCreated(project);
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-4" noValidate>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Input
          id="name"
          label="Project Name"
          placeholder="e.g. Brand Refresh"
          value={name}
          onChange={(e) => setName(e.target.value)}
          error={errors.name}
          autoFocus
        />
        <Input
          id="client"
          label="Client"
          placeholder="e.g. Acme Corp"
          value={client}
          onChange={(e) => setClient(e.target.value)}
          error={errors.client}
        />
      </div>
      <div className="flex items-center gap-2 pt-1">
        <Button type="submit" loading={loading}>
          Create project
        </Button>
        <Button type="button" variant="ghost" onClick={onCancel}>
          Cancel
        </Button>
      </div>
    </form>
  );
}
