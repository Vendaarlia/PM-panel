import type { ReactNode } from "react";

interface Props {
  children: ReactNode;
}

export function Shell({ children }: Props) {
  return (
    <div className="min-h-screen bg-[#F7F7F5] font-sans antialiased">
      {/* Top nav */}
      <header className="border-b border-zinc-200 bg-white">
        <div className="max-w-5xl mx-auto px-6 h-14 flex items-center justify-between">
          <a href="#" onClick={() => window.dispatchEvent(new CustomEvent("navigate", { detail: { page: "dashboard" } }))} className="flex items-center gap-2.5 group cursor-pointer">
            <span className="inline-flex items-center justify-center w-6 h-6 rounded bg-zinc-900 text-white text-[10px] font-bold tracking-tight">V</span>
            <span className="text-sm font-semibold text-zinc-900 tracking-tight">Vendaar</span>
            <span className="text-zinc-300 text-sm">/</span>
            <span className="text-sm text-zinc-500">Handoff</span>
          </a>
          <nav className="flex items-center gap-1 text-xs text-zinc-400">
            <span className="px-2 py-1 rounded bg-zinc-100 text-zinc-600 font-medium">Internal</span>
          </nav>
        </div>
      </header>

      {/* Page */}
      <main className="max-w-5xl mx-auto px-6 py-10">
        {children}
      </main>
    </div>
  );
}
