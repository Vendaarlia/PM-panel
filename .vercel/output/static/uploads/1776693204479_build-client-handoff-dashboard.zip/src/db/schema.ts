// Mirrors Drizzle ORM schema for SQLite
// In this browser build, persistence is handled by localStorage via lib/db.ts

export type ProjectStatus = "draft" | "review" | "done";

export interface Project {
  id: string;
  name: string;
  client: string;
  status: ProjectStatus;
  created_at: string; // ISO timestamp
}

export interface Note {
  id: string;
  project_id: string;
  content: string;
  created_at: string; // ISO timestamp
}
