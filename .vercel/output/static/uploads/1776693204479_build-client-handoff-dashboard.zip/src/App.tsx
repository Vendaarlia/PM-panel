// App.tsx — Client-side router (mirrors Astro file-based routing)
// Routes: / (Dashboard) | /project/:id (ProjectDetail)

import { useState, useEffect } from "react";
import { Dashboard } from "@/pages/Dashboard";
import { ProjectDetail } from "@/pages/ProjectDetail";

type Page = "dashboard" | "project";

interface RouteState {
  page: Page;
  params: Record<string, string>;
}

export default function App() {
  const [route, setRoute] = useState<RouteState>({ page: "dashboard", params: {} });

  // Listen for programmatic navigation events from Shell header logo
  useEffect(() => {
    function onNavigate(e: Event) {
      const detail = (e as CustomEvent).detail;
      setRoute({ page: detail.page, params: detail.params ?? {} });
    }
    window.addEventListener("navigate", onNavigate);
    return () => window.removeEventListener("navigate", onNavigate);
  }, []);

  function navigate(page: string, params: Record<string, string> = {}) {
    setRoute({ page: page as Page, params });
  }

  if (route.page === "project" && route.params.id) {
    return (
      <ProjectDetail
        projectId={route.params.id}
        onBack={() => navigate("dashboard")}
      />
    );
  }

  return <Dashboard onNavigate={navigate} />;
}
