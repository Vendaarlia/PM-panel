// pages/index.astro equivalent — Dashboard page

import { useState } from "react";
import { Shell } from "@/components/layout/Shell";
import { ProjectForm } from "@/components/vue/ProjectForm";
import { ProjectList } from "@/components/vue/ProjectList";
import { Button } from "@/components/ui/Button";
import { apiGetProjects } from "@/lib/query";
import type { Project } from "@/db/schema";

interface Props {
  onNavigate: (page: string, params?: Record<string, string>) => void;
}

export function Dashboard({ onNavigate }: Props) {
  const [projects, setProjects] = useState<Project[]>(() => apiGetProjects());
  const [showForm, setShowForm] = useState(false);

  function handleCreated(project: Project) {
    setProjects([project, ...projects]);
    setShowForm(false);
  }

  function handleDelete(id: string) {
    setProjects(projects.filter((p) => p.id !== id));
  }

  const counts = {
    draft: projects.filter((p) => p.status === "draft").length,
    review: projects.filter((p) => p.status === "review").length,
    done: projects.filter((p) => p.status === "done").length,
  };

  return (
    <Shell>
      {/* Page header */}
      <div className="flex items-start justify-between mb-8">
        <div>
          <h1 className="text-xl font-semibold text-zinc-900 tracking-tight">
            Projects
          </h1>
          <p className="text-sm text-zinc-400 mt-1">
            Manage client handoffs and delivery status.
          </p>
        </div>
        {!showForm && (
          <Button onClick={() => setShowForm(true)}>
            <svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
            </svg>
            New project
          </Button>
        )}
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-3 gap-3 mb-8">
        {(
          [
            { label: "Draft", value: counts.draft, color: "text-zinc-500", dot: "bg-zinc-300" },
            { label: "In Review", value: counts.review, color: "text-amber-600", dot: "bg-amber-400" },
            { label: "Done", value: counts.done, color: "text-emerald-600", dot: "bg-emerald-400" },
          ] as const
        ).map(({ label, value, color, dot }) => (
          <div key={label} className="bg-white border border-zinc-200 rounded-xl px-5 py-4">
            <div className="flex items-center gap-2 mb-1">
              <span className={`w-1.5 h-1.5 rounded-full ${dot}`} />
              <span className="text-xs text-zinc-400 font-medium">{label}</span>
            </div>
            <span className={`text-2xl font-semibold tracking-tight ${color}`}>{value}</span>
          </div>
        ))}
      </div>

      {/* Create form (inline) */}
      {showForm && (
        <div className="mb-6 bg-white border border-zinc-200 rounded-xl px-5 py-5">
          <h2 className="text-sm font-medium text-zinc-700 mb-4">New Project</h2>
          <ProjectForm
            onCreated={handleCreated}
            onCancel={() => setShowForm(false)}
          />
        </div>
      )}

      {/* Project list */}
      <ProjectList
        projects={projects}
        onSelect={(id) => onNavigate("project", { id })}
        onDelete={handleDelete}
      />
    </Shell>
  );
}
