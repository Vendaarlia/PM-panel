// pages/project/[id].astro equivalent — Project detail page

import { useState } from "react";
import { Shell } from "@/components/layout/Shell";
import { Notes } from "@/components/vue/Notes";
import { StatusBadge } from "@/components/ui/StatusBadge";
import { Button } from "@/components/ui/Button";
import { apiGetProject, apiGetNotes, apiUpdateStatus } from "@/lib/query";
import type { Project, ProjectStatus } from "@/db/schema";

interface Props {
  projectId: string;
  onBack: () => void;
}

const STATUS_FLOW: ProjectStatus[] = ["draft", "review", "done"];

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString("en-GB", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}

function nextStatus(current: ProjectStatus): ProjectStatus | null {
  const idx = STATUS_FLOW.indexOf(current);
  return idx < STATUS_FLOW.length - 1 ? STATUS_FLOW[idx + 1] : null;
}

const nextLabel: Record<ProjectStatus, string> = {
  draft: "Move to Review",
  review: "Mark as Done",
  done: "",
};

export function ProjectDetail({ projectId, onBack }: Props) {
  const [project, setProject] = useState<Project | null>(() => {
    try {
      return apiGetProject(projectId);
    } catch {
      return null;
    }
  });
  const notes = project ? apiGetNotes(project.id) : [];

  if (!project) {
    return (
      <Shell>
        <div className="text-center py-20">
          <p className="text-sm text-zinc-400">Project not found.</p>
          <Button variant="ghost" size="sm" className="mt-4" onClick={onBack}>
            ← Back to dashboard
          </Button>
        </div>
      </Shell>
    );
  }

  function handleStatusAdvance() {
    if (!project) return;
    const next = nextStatus(project.status);
    if (!next) return;
    const updated = apiUpdateStatus(project.id, next);
    setProject(updated);
  }

  const next = nextStatus(project.status);

  return (
    <Shell>
      {/* Back */}
      <button
        onClick={onBack}
        className="inline-flex items-center gap-1.5 text-xs text-zinc-400 hover:text-zinc-700 mb-6 transition-colors duration-100 cursor-pointer"
      >
        <svg width="12" height="12" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 19.5L3 12m0 0l7.5-7.5M3 12h18" />
        </svg>
        All projects
      </button>

      {/* Header */}
      <div className="flex items-start justify-between gap-4 mb-8">
        <div>
          <div className="flex items-center gap-3 mb-1">
            <h1 className="text-xl font-semibold text-zinc-900 tracking-tight">
              {project.name}
            </h1>
            <StatusBadge status={project.status} />
          </div>
          <p className="text-sm text-zinc-400">
            {project.client} · Created {formatDate(project.created_at)}
          </p>
        </div>

        {next && (
          <Button variant="outline" onClick={handleStatusAdvance}>
            {nextLabel[project.status]}
            <svg width="12" height="12" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3" />
            </svg>
          </Button>
        )}
        {!next && (
          <span className="inline-flex items-center gap-1.5 text-xs text-emerald-600 bg-emerald-50 border border-emerald-200 rounded-lg px-3 py-2">
            <svg width="12" height="12" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" />
            </svg>
            Handoff complete
          </span>
        )}
      </div>

      {/* Status tracker */}
      <div className="bg-white border border-zinc-200 rounded-xl px-5 py-4 mb-6">
        <p className="text-[10px] font-medium text-zinc-400 uppercase tracking-wider mb-3">
          Status
        </p>
        <div className="flex items-center gap-0">
          {STATUS_FLOW.map((s, i) => {
            const currentIdx = STATUS_FLOW.indexOf(project.status);
            const isCompleted = i < currentIdx;
            const isActive = i === currentIdx;

            return (
              <div key={s} className="flex items-center flex-1">
                <div className="flex flex-col items-center gap-1.5 flex-1">
                  <div
                    className={`w-2.5 h-2.5 rounded-full transition-colors duration-300 ${
                      isActive
                        ? "bg-zinc-900 ring-2 ring-zinc-900/20 ring-offset-1"
                        : isCompleted
                        ? "bg-zinc-900"
                        : "bg-zinc-200"
                    }`}
                  />
                  <span
                    className={`text-[10px] font-medium capitalize ${
                      isActive ? "text-zinc-900" : isCompleted ? "text-zinc-500" : "text-zinc-300"
                    }`}
                  >
                    {s === "review" ? "In Review" : s.charAt(0).toUpperCase() + s.slice(1)}
                  </span>
                </div>
                {i < STATUS_FLOW.length - 1 && (
                  <div
                    className={`h-px flex-1 mb-4 transition-colors duration-300 ${
                      isCompleted ? "bg-zinc-900" : "bg-zinc-200"
                    }`}
                  />
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Notes section */}
      <div className="bg-white/60 border border-zinc-200 rounded-xl px-5 py-5">
        <p className="text-[10px] font-medium text-zinc-400 uppercase tracking-wider mb-4">
          Notes
        </p>
        <Notes projectId={project.id} initialNotes={notes} />
      </div>
    </Shell>
  );
}
