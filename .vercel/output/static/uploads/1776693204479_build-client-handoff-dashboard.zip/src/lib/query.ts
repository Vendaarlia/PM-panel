// lib/query.ts
// Thin API query layer — mirrors Astro API route handlers.
// On a real stack these would be fetch() calls to /api/projects, /api/notes.

import {
  getAllProjects,
  getProjectById,
  createProject,
  updateProjectStatus,
  deleteProject,
  getNotesByProject,
  createNote,
  deleteNote,
} from "@/lib/db";

import type { Project, Note } from "@/db/schema";

// ── /api/projects (GET) ───────────────────────────────────────────────────────
export function apiGetProjects(): Project[] {
  return getAllProjects();
}

// ── /api/projects (POST) ──────────────────────────────────────────────────────
export function apiCreateProject(name: string, client: string): Project {
  if (!name.trim()) throw new Error("Project name is required.");
  if (!client.trim()) throw new Error("Client name is required.");
  return createProject({ name: name.trim(), client: client.trim() });
}

// ── /api/projects/:id (GET) ───────────────────────────────────────────────────
export function apiGetProject(id: string): Project {
  const p = getProjectById(id);
  if (!p) throw new Error("Project not found.");
  return p;
}

// ── /api/projects/:id/status (PATCH) ─────────────────────────────────────────
export function apiUpdateStatus(
  id: string,
  status: Project["status"]
): Project {
  const p = updateProjectStatus(id, status);
  if (!p) throw new Error("Project not found.");
  return p;
}

// ── /api/projects/:id (DELETE) ────────────────────────────────────────────────
export function apiDeleteProject(id: string): void {
  deleteProject(id);
}

// ── /api/notes?project_id= (GET) ─────────────────────────────────────────────
export function apiGetNotes(project_id: string): Note[] {
  return getNotesByProject(project_id);
}

// ── /api/notes (POST) ─────────────────────────────────────────────────────────
export function apiCreateNote(project_id: string, content: string): Note {
  if (!content.trim()) throw new Error("Note content is required.");
  return createNote({ project_id, content: content.trim() });
}

// ── /api/notes/:id (DELETE) ───────────────────────────────────────────────────
export function apiDeleteNote(id: string): void {
  deleteNote(id);
}
