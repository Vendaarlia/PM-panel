// lib/db.ts
// Client-side persistence layer — mirrors SQLite via localStorage.
// On a real Astro/Bun stack this would initialise better-sqlite3 + Drizzle.

import type { Project, Note } from "@/db/schema";

const PROJECTS_KEY = "vendaar:projects";
const NOTES_KEY = "vendaar:notes";

// ── helpers ──────────────────────────────────────────────────────────────────

function readProjects(): Project[] {
  try {
    return JSON.parse(localStorage.getItem(PROJECTS_KEY) ?? "[]");
  } catch {
    return [];
  }
}

function writeProjects(projects: Project[]): void {
  localStorage.setItem(PROJECTS_KEY, JSON.stringify(projects));
}

function readNotes(): Note[] {
  try {
    return JSON.parse(localStorage.getItem(NOTES_KEY) ?? "[]");
  } catch {
    return [];
  }
}

function writeNotes(notes: Note[]): void {
  localStorage.setItem(NOTES_KEY, JSON.stringify(notes));
}

function uid(): string {
  return crypto.randomUUID();
}

function now(): string {
  return new Date().toISOString();
}

// ── projects ──────────────────────────────────────────────────────────────────

export function getAllProjects(): Project[] {
  return readProjects().sort(
    (a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
  );
}

export function getProjectById(id: string): Project | undefined {
  return readProjects().find((p) => p.id === id);
}

export function createProject(data: Pick<Project, "name" | "client">): Project {
  const project: Project = {
    id: uid(),
    name: data.name,
    client: data.client,
    status: "draft",
    created_at: now(),
  };
  writeProjects([...readProjects(), project]);
  return project;
}

export function updateProjectStatus(
  id: string,
  status: Project["status"]
): Project | undefined {
  const projects = readProjects();
  const idx = projects.findIndex((p) => p.id === id);
  if (idx === -1) return undefined;
  projects[idx] = { ...projects[idx], status };
  writeProjects(projects);
  return projects[idx];
}

export function deleteProject(id: string): void {
  writeProjects(readProjects().filter((p) => p.id !== id));
  writeNotes(readNotes().filter((n) => n.project_id !== id));
}

// ── notes ─────────────────────────────────────────────────────────────────────

export function getNotesByProject(project_id: string): Note[] {
  return readNotes()
    .filter((n) => n.project_id === project_id)
    .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
}

export function createNote(data: Pick<Note, "project_id" | "content">): Note {
  const note: Note = {
    id: uid(),
    project_id: data.project_id,
    content: data.content,
    created_at: now(),
  };
  writeNotes([...readNotes(), note]);
  return note;
}

export function deleteNote(id: string): void {
  writeNotes(readNotes().filter((n) => n.id !== id));
}
