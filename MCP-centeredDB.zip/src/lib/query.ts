import { eq, desc } from 'drizzle-orm';
import { db } from './db';
import { users, projects, notes, type NewUser, type NewProject, type NewNote } from '../db/schema';

// User queries
export async function getUserByEmail(email: string) {
  return db.query.users.findFirst({
    where: eq(users.email, email),
  });
}

export async function getUserById(id: number) {
  return db.query.users.findFirst({
    where: eq(users.id, id),
  });
}

export async function createUser(data: NewUser) {
  const result = await db.insert(users).values(data).returning();
  return result[0];
}

export async function getAllProjects() {
  return db.query.projects.findMany({
    orderBy: desc(projects.createdAt),
  });
}

export async function getProjectById(id: number) {
  return db.query.projects.findFirst({
    where: eq(projects.id, id),
  });
}

export async function createProject(data: NewProject) {
  const result = await db.insert(projects).values(data).returning();
  return result[0];
}

export async function updateProjectStatus(id: number, status: 'draft' | 'review' | 'done') {
  const result = await db
    .update(projects)
    .set({ status })
    .where(eq(projects.id, id))
    .returning();
  return result[0];
}

export async function deleteProject(id: number) {
  return db.delete(projects).where(eq(projects.id, id));
}

export async function getNotesByProjectId(projectId: number) {
  return db.query.notes.findMany({
    where: eq(notes.projectId, projectId),
    orderBy: desc(notes.createdAt),
  });
}

export async function createNote(data: NewNote) {
  const result = await db.insert(notes).values(data).returning();
  return result[0];
}

export async function deleteNote(id: number) {
  return db.delete(notes).where(eq(notes.id, id));
}

export async function getProjectByShareToken(token: string) {
  return db.query.projects.findFirst({
    where: eq(projects.shareToken, token),
  });
}

export async function updateProjectStatusByShareToken(token: string, status: 'draft' | 'review' | 'done') {
  const result = await db
    .update(projects)
    .set({ status })
    .where(eq(projects.shareToken, token))
    .returning();
  return result[0];
}
