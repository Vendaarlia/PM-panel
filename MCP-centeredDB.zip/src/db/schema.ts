import { sqliteTable, integer, text } from 'drizzle-orm/sqlite-core';
import { randomUUID } from 'crypto';

export const users = sqliteTable('users', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  name: text('name').notNull(),
  email: text('email').notNull().unique(),
  passwordHash: text('password_hash').notNull(),
  createdAt: integer('created_at', { mode: 'timestamp' }).notNull().$default(() => new Date()),
});

export const projects = sqliteTable('projects', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  name: text('name').notNull(),
  client: text('client').notNull(),
  description: text('description'),
  status: text('status', { enum: ['draft', 'review', 'done'] }).notNull().default('draft'),
  shareToken: text('share_token').notNull().$default(() => randomUUID()),
  createdAt: integer('created_at', { mode: 'timestamp' }).notNull().$default(() => new Date()),
});

export const notes = sqliteTable('notes', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  projectId: integer('project_id').notNull().references(() => projects.id, { onDelete: 'cascade' }),
  content: text('content').notNull(),
  authorRole: text('author_role', { enum: ['admin', 'client'] }).notNull().default('client'),
  authorName: text('author_name').notNull().default('Client'),
  attachmentUrl: text('attachment_url'),
  attachmentType: text('attachment_type'),
  attachmentName: text('attachment_name'),
  createdAt: integer('created_at', { mode: 'timestamp' }).notNull().$default(() => new Date()),
});

export type User = typeof users.$inferSelect;
export type NewUser = typeof users.$inferInsert;
export type Project = typeof projects.$inferSelect;
export type NewProject = typeof projects.$inferInsert;
export type Note = typeof notes.$inferSelect;
export type NewNote = typeof notes.$inferInsert;
