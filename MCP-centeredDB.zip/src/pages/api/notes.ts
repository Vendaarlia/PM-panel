import type { APIRoute } from 'astro';
import { getNotesByProjectId, createNote, deleteNote } from '../../lib/query';

export const GET: APIRoute = async ({ request }) => {
  try {
    const { searchParams } = new URL(request.url);
    const projectId = searchParams.get('project_id');

    if (!projectId) {
      return new Response(
        JSON.stringify({ error: 'project_id is required' }),
        { status: 400, headers: { 'Content-Type': 'application/json' } }
      );
    }

    const notes = await getNotesByProjectId(Number(projectId));
    return new Response(JSON.stringify(notes), {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (error) {
    return new Response(JSON.stringify({ error: 'Failed to fetch notes' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }
};

export const POST: APIRoute = async ({ request }) => {
  try {
    const body = await request.json();
    const { projectId, content } = body;

    if (!projectId || !content) {
      return new Response(
        JSON.stringify({ error: 'projectId and content are required' }),
        { status: 400, headers: { 'Content-Type': 'application/json' } }
      );
    }

    const note = await createNote({
      projectId,
      content,
      authorRole: body.authorRole || 'admin',
      authorName: body.authorName || 'Admin',
      attachmentUrl: body.attachment?.url,
      attachmentType: body.attachment?.type,
      attachmentName: body.attachment?.name,
    });

    return new Response(JSON.stringify(note), {
      status: 201,
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (error) {
    return new Response(JSON.stringify({ error: 'Failed to create note' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }
};

export const DELETE: APIRoute = async ({ request }) => {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return new Response(
        JSON.stringify({ error: 'ID is required' }),
        { status: 400, headers: { 'Content-Type': 'application/json' } }
      );
    }

    await deleteNote(Number(id));

    return new Response(JSON.stringify({ success: true }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (error) {
    return new Response(JSON.stringify({ error: 'Failed to delete note' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }
};
